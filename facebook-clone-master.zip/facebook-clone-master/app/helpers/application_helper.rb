# frozen_string_literal: true

module ApplicationHelper
end
